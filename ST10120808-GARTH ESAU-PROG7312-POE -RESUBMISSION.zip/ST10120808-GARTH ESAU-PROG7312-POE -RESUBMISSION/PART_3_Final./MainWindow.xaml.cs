﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace PART_3_Final
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    /// 
    public class Library
    {
        public Library()
        {
            this.Books = new List<Book>();
        }

        public string Name { get; set; }

        public List<Book> Books { get; set; }
    }

    public class Book
    {
        public string Name { get; set; }

        public int Number { get; set; }
    }

    public partial class MainWindow : Window
    {
        // ============================================================== REPLACE VARIABLES ==========================================================

        //List for Call Numbers
        List<string> callNumbs = new List<string>();

        //List for author names
        List<string> authors = new List<string>();

        //List for sorted Call Numbers
        List<string> sortedList = new List<string>();

        //List for users
        List<string> userList = new List<string>();

        // ============================================================== IDENTIFY VARIBLES =============================================================
        List<string> keywords = new List<string>();
        List<string> definitions = new List<string>();


        private void bubbleSort(List<string> stList)
        {
            for (int i = 0; i < stList.Count - 1; i++)
            {   //10, 5, 21, 7, 13
                for (int k = (i + 1); k < stList.Count; k++)
                {
                    if (stList[i].CompareTo(stList[k]) == 1)
                    {
                        string temp = stList[i];
                        stList[i] = stList[k];
                        stList[k] = temp;
                    }
                }
            }
        }

        public MainWindow()
        {
            InitializeComponent();
        }

        // =========================== Home Screen ==========================================
        private void ReplaceButtonClick(object sender, RoutedEventArgs e)
        {
            userList.Clear();
            sortedList.Clear();
            callNumbs.Clear();

            ResultList.Items.Clear();
            OriginalList.Items.Clear();

            Random rnd = new Random();

            //Adding authors to author list
            authors.Add("GOL");
            authors.Add("CHA");
            authors.Add("JAN");
            authors.Add("WIL");
            authors.Add("HOM");
            authors.Add("SOC");
            authors.Add("ARI");
            authors.Add("MAR");
            authors.Add("FRI");
            authors.Add("MAC");
            authors.Add("SAL");
            authors.Add("KAF");
            authors.Add("GAR");
            authors.Add("WES");
            authors.Add("MAL");
            authors.Add("CAR");
            authors.Add("MIL");
            authors.Add("TRA");
            authors.Add("JEN");
            authors.Add("MIC");
            authors.Add("GLO");
            authors.Add("OKA");

            //Adding random numbers to Call Number List
            for (int i = 0; i < 10; i++)
            {
                int ran = rnd.Next(1, 99);

                string rd = ran.ToString();

                if (rd.Length == 2)
                {
                    string temp = rd;
                    rd = "0" + temp;
                }
                else if (rd.Length == 1)
                {
                    string temp = rd;
                    rd = "00" + temp;
                }

                callNumbs.Add(rd + authors[rnd.Next(1, 22)]);
            }

            //Displaying the Call Numbers
            foreach (string item in callNumbs)
            {
                OriginalList.Items.Add(item);
            }

            // Sorting of Call Numbers
            sortedList = callNumbs;
            bubbleSort(sortedList);

            MyTab.SelectedIndex = 1;
        }

        private void IdentifyButtonClick(object sender, RoutedEventArgs e)
        {
            keywords.Clear();
            definitions.Clear();
            KeyList.Items.Clear();
            AnswerList.Items.Clear();

            keywords.Add("Computer");
            keywords.Add("Hardware");
            keywords.Add("Software");
            keywords.Add("Internet");

            definitions.Add("This is a piecce of machine that allows a user to do computations");
            definitions.Add("This is the physical piece of a computer");
            definitions.Add("This is a internal software that runs a computer");
            definitions.Add("This is a series of computers that are conected to one another");
            definitions.Add("This is a mobile device that can be stored in a pocket");
            definitions.Add("This is a internet service provider");
            
            //Random rnd = new Random();
            
            foreach (string item in keywords)
            {
                KeyList.Items.Add(item);
            }

            foreach (string item in definitions)
            {
                AnswerList.Items.Add(item);
            }

            MyTab.SelectedIndex = 2;
        }

        private void FindingButtonClick(object sender, RoutedEventArgs e)
        {
           
            List<Library> libraries = new List<Library>();

            Library lib1 = new Library() { Name = "Programming"};
            lib1.Books.Add(new Book() { Name = "Computer Programming", Number = 123 });
            lib1.Books.Add(new Book() { Name = "Python Programming", Number = 150 });
            lib1.Books.Add(new Book() { Name = "Java Programming", Number = 153 });
            lib1.Books.Add(new Book() { Name = "C# Programming", Number = 159 });
            lib1.Books.Add(new Book() { Name = "C++ Programming", Number = 163 });
            libraries.Add(lib1);

            Library lib2 = new Library() { Name = "Theory" };
            lib2.Books.Add(new Book() { Name = "Hardware Design", Number = 223 });
            lib2.Books.Add(new Book() { Name = "UI & UX", Number = 250 });
            lib2.Books.Add(new Book() { Name = "Arrays & Collections", Number = 253 });
            lib2.Books.Add(new Book() { Name = "Interfaces", Number = 259 });
            lib2.Books.Add(new Book() { Name = "Interviews", Number = 263 });
            libraries.Add(lib2);

            

            TreeView t = new TreeView();
            TreeViewItem tv1 = new TreeViewItem();
            tv1.Header = lib1.Name;
            TreeViewItem tv2 = new TreeViewItem();
            tv2.Header = lib2.Name;
 

            MyTab.SelectedIndex = 3;
        }

        // =======================================================  Replace Tab Screen ===================================================================
        private void ValidateButtonClick(object sender, RoutedEventArgs e)
        {
            //Getting all items in the listbox and adding them to the user List
            for (int i = 0; i < ResultList.Items.Count; i++)
            {
                string item = ResultList.Items[i].ToString();

                userList.Add(item);
            }

            int count = 0;
            if (userList.Count == sortedList.Count)
            {
                for (int i = 0; i < sortedList.Count; i++)
                {
                    if (sortedList[i] == userList[i])
                    {
                        count++;
                    }
                }
            }

            if (count == sortedList.Count)
            {
                // MessageBox.Show("CORRECT");
                ResultText.Content = "Correct Sorting Arrangement";
            }
            else
            {
                MessageBox.Show("INCORRECT", "Student Application",
                MessageBoxButton.OK, MessageBoxImage.Error);
            }
        }


        private void OriginalList_MouseMove(object sender, MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                DragDrop.DoDragDrop(this, OriginalList.SelectedItem.ToString(), DragDropEffects.Move);
            }
        }

        private void ResultList_Drop(object sender, DragEventArgs e)
        {
            var myObj = e.Data.GetData(DataFormats.Text);
            OriginalList.Items.Remove(OriginalList.SelectedItem);
            ResultList.Items.Add(myObj);

            if (ResultList.Items.Contains(ResultList.SelectedItem))
            {
                ResultList.Items.Remove(OriginalList.SelectedItem);
                //ResultList.Items.Remove(ResultList.SelectedItem);
            }

            if (ResultList.Items.Count > 0)
            {
                ValidateButton.IsEnabled = true;
            }
        }

        private void ResultList_MouseMove(object sender, MouseEventArgs e)
        {
            base.OnMouseMove(e);
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                DragDrop.DoDragDrop(this, ResultList.SelectedItem.ToString(), DragDropEffects.Move);
            }
        }

        private void OriginalList_Drop(object sender, DragEventArgs e)
        {
            var myObj = e.Data.GetData(DataFormats.Text);
            ResultList.Items.Remove(ResultList.SelectedItem);
            OriginalList.Items.Add(myObj);

            if (OriginalList.Items.Contains(OriginalList.SelectedItem))
            {
                OriginalList.Items.Remove(ResultList.SelectedItem);
                OriginalList.Items.Remove(OriginalList.SelectedItem);
            }



            if (ResultList.Items.Count < 1)
            {
                ValidateButton.IsEnabled = false;
            }
        }

        // ================================================================== IDENTIFY Functions =========================================================================

        // =================================================================== FIND Functions =============================================================================

    }
}
